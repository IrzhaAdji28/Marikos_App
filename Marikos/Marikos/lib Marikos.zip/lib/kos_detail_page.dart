import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'models.dart';
import 'api_service.dart';
import 'chat_page.dart';

class KosDetailPage extends StatefulWidget {
  final Kos kos;

  const KosDetailPage({Key? key, required this.kos}) : super(key: key);

  @override
  _KosDetailPageState createState() => _KosDetailPageState();
}

class _KosDetailPageState extends State<KosDetailPage> {
  final ApiService _apiService = ApiService();
  bool _isBookingLoading = false;

  // Variabel untuk Form Booking
  DateTime _selectedDate = DateTime.now();
  int _duration = 1; // Default 1 bulan

  @override
  Widget build(BuildContext context) {
    // Format mata uang
    final currencyFormatter = NumberFormat.currency(locale: 'id_ID', symbol: 'Rp ', decimalDigits: 0);

    return Scaffold(
      body: Stack(
        children: [
          // 1. KONTEN UTAMA (Scrollable)
          CustomScrollView(
            slivers: [
              // HEADER GAMBAR
              SliverAppBar(
                expandedHeight: 250.0,
                pinned: true,
                backgroundColor: Colors.purple.shade700,
                flexibleSpace: FlexibleSpaceBar(
                  background: widget.kos.images.isNotEmpty
                      ? Image.network(
                          widget.kos.images[0],
                          fit: BoxFit.cover,
                          errorBuilder: (c, e, s) => Container(color: Colors.grey, child: Icon(Icons.broken_image, size: 50)),
                        )
                      : Container(color: Colors.grey, child: Icon(Icons.image, size: 50)),
                ),
                leading: IconButton(
                  icon: CircleAvatar(
                    backgroundColor: Colors.white54,
                    child: Icon(Icons.arrow_back, color: Colors.black),
                  ),
                  onPressed: () => Navigator.pop(context),
                ),
              ),

              // BODY DETAIL
              SliverToBoxAdapter(
                child: Container(
                  padding: EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Judul & Tipe
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Expanded(
                            child: Text(
                              widget.kos.name,
                              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
                            ),
                          ),
                          _buildTypeChip(widget.kos.type),
                        ],
                      ),
                      SizedBox(height: 8),

                      // Rating
                      Row(
                        children: [
                          Icon(Icons.star, color: Colors.amber, size: 18),
                          Text(" ${widget.kos.rating} (${widget.kos.reviewCount} ulasan)", style: TextStyle(color: Colors.grey[600])),
                        ],
                      ),
                      SizedBox(height: 16),

                      // --- BAGIAN ALAMAT YANG DIPERBAIKI ---
                      Text("Lokasi", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                      SizedBox(height: 8),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Icon(Icons.location_on, color: Colors.red, size: 20),
                          SizedBox(width: 8),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                // Menampilkan Alamat Lengkap dari Database
                                Text(
                                  widget.kos.address.isNotEmpty ? widget.kos.address : "Alamat tidak tersedia",
                                  style: TextStyle(fontSize: 14, color: Colors.black87, height: 1.3),
                                ),
                                SizedBox(height: 4),
                                // Menampilkan Kota (Default 'Bandung' dari API)
                                Text(
                                  widget.kos.location, 
                                  style: TextStyle(color: Colors.grey, fontSize: 12)
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                      Divider(height: 32),

                      // Pemilik Kos
                      Row(
                        children: [
                          CircleAvatar(
                            backgroundColor: Colors.purple.shade100,
                            child: Text(
                              widget.kos.ownerName.isNotEmpty ? widget.kos.ownerName[0].toUpperCase() : '?',
                              style: TextStyle(color: Colors.purple)
                            ),
                          ),
                          SizedBox(width: 12),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text("Pemilik", style: TextStyle(fontSize: 12, color: Colors.grey)),
                              Text(widget.kos.ownerName, style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                            ],
                          ),
                          Spacer(),
                          // Tombol Chat
                          OutlinedButton.icon(
                            onPressed: () async {
                              // Ambil ID User Saya (yang sedang login)
                              String? myId = await _apiService.getCurrentUserId();
                              
                              // Cek: Jangan chat diri sendiri
                              if (myId == widget.kos.ownerId) {
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(content: Text("Ini kos milik Anda sendiri"))
                                );
                                return;
                              }

                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => ChatPage(
                                    // GUNAKAN ID ASLI DARI DATABASE
                                    receiverId: widget.kos.ownerId, 
                                    receiverName: widget.kos.ownerName,
                                  ),
                                ),
                              );
                            },
                            icon: Icon(Icons.chat_bubble_outline, size: 18),
                            label: Text("Chat"),
                            style: OutlinedButton.styleFrom(
                              foregroundColor: Colors.purple,
                              side: BorderSide(color: Colors.purple),
                            ),
                          )
                        ],
                      ),
                      Divider(height: 32),

                      // Fasilitas
                      Text("Fasilitas Utama", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                      SizedBox(height: 12),
                      widget.kos.facilities.isNotEmpty 
                      ? Wrap(
                          spacing: 8,
                          runSpacing: 8,
                          children: widget.kos.facilities.map((fasilitas) {
                            return Chip(
                              label: Text(fasilitas),
                              backgroundColor: Colors.purple.shade50,
                              labelStyle: TextStyle(color: Colors.purple.shade900),
                            );
                          }).toList(),
                        )
                      : Text("- Tidak ada data fasilitas -", style: TextStyle(color: Colors.grey)),
                      SizedBox(height: 24),

                      // Deskripsi
                      Text("Deskripsi", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                      SizedBox(height: 8),
                      Text(
                        widget.kos.description.isNotEmpty ? widget.kos.description : "Tidak ada deskripsi tersedia.",
                        style: TextStyle(color: Colors.grey[800], height: 1.5),
                      ),
                      
                      SizedBox(height: 100), // Spacer untuk bottom bar
                    ],
                  ),
                ),
              ),
            ],
          ),

          // 2. BOTTOM BAR (Harga & Booking)
          Align(
            alignment: Alignment.bottomCenter,
            child: Container(
              padding: EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 10, offset: Offset(0, -5))],
              ),
              child: Row(
                children: [
                  Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text("Harga Sewa", style: TextStyle(color: Colors.grey)),
                      Text(
                        currencyFormatter.format(widget.kos.price),
                        style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.purple.shade700),
                      ),
                      Text("/ bulan", style: TextStyle(fontSize: 12, color: Colors.grey)),
                    ],
                  ),
                  Spacer(),
                  SizedBox(
                    height: 50,
                    width: 160,
                    child: ElevatedButton(
                      onPressed: () => _showBookingDialog(context),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.purple.shade700,
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      ),
                      child: Text("Ajukan Sewa", style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // WIDGET HELPER: Label Tipe Kos
  Widget _buildTypeChip(String type) {
    Color color;
    switch (type.toLowerCase()) {
      case 'putra': color = Colors.blue; break;
      case 'putri': color = Colors.pink; break;
      default: color = Colors.purple;
    }
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(color: color.withOpacity(0.1), borderRadius: BorderRadius.circular(20)),
      child: Text(type.toUpperCase(), style: TextStyle(color: color, fontWeight: FontWeight.bold, fontSize: 12)),
    );
  }

  // FUNGSI: Tampilkan Dialog Konfirmasi Booking
  void _showBookingDialog(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (context) {
        return StatefulBuilder(
          builder: (BuildContext context, StateSetter setModalState) {
            double totalPrice = widget.kos.price * _duration;

            return Padding(
              padding: EdgeInsets.all(24),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text("Atur Pesanan", style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                  SizedBox(height: 20),
                  
                  // PILIH TANGGAL
                  Text("Mulai Kos", style: TextStyle(fontWeight: FontWeight.bold)),
                  SizedBox(height: 8),
                  InkWell(
                    onTap: () async {
                      DateTime? picked = await showDatePicker(
                        context: context,
                        initialDate: _selectedDate,
                        firstDate: DateTime.now(),
                        lastDate: DateTime(2030),
                      );
                      if (picked != null) {
                        setModalState(() => _selectedDate = picked);
                      }
                    },
                    child: Container(
                      padding: EdgeInsets.symmetric(horizontal: 12, vertical: 12),
                      decoration: BoxDecoration(
                        border: Border.all(color: Colors.grey.shade300),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Row(
                        children: [
                          Icon(Icons.calendar_today, size: 18, color: Colors.purple),
                          SizedBox(width: 8),
                          Text(DateFormat('dd MMMM yyyy', 'id_ID').format(_selectedDate)),
                        ],
                      ),
                    ),
                  ),
                  SizedBox(height: 16),

                  // PILIH DURASI
                  Text("Lama Sewa", style: TextStyle(fontWeight: FontWeight.bold)),
                  SizedBox(height: 8),
                  Row(
                    children: [
                      IconButton(
                        icon: Icon(Icons.remove_circle_outline),
                        onPressed: _duration > 1 
                          ? () => setModalState(() => _duration--) 
                          : null,
                      ),
                      Text("$_duration Bulan", style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                      IconButton(
                        icon: Icon(Icons.add_circle_outline),
                        onPressed: () => setModalState(() => _duration++),
                      ),
                    ],
                  ),
                  Divider(),
                  
                  // TOTAL HARGA
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text("Total Pembayaran", style: TextStyle(fontSize: 16)),
                      Text(
                        NumberFormat.currency(locale: 'id_ID', symbol: 'Rp ', decimalDigits: 0).format(totalPrice),
                        style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.purple),
                      ),
                    ],
                  ),
                  SizedBox(height: 24),

                  // TOMBOL KONFIRMASI
                  SizedBox(
                    width: double.infinity,
                    height: 50,
                    child: ElevatedButton(
                      onPressed: _isBookingLoading 
                        ? null 
                        : () {
                            Navigator.pop(context); // Tutup Dialog
                            _processBooking(totalPrice);
                          },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.purple.shade700,
                        foregroundColor: Colors.white,
                      ),
                      child: Text("Lanjutkan ke Pembayaran"),
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  // FUNGSI: Kirim Data Booking ke Server
  void _processBooking(double totalPrice) async {
    setState(() => _isBookingLoading = true);

    String? userId = await _apiService.getCurrentUserId();
    
    if (userId == null) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Silakan login terlebih dahulu")));
      setState(() => _isBookingLoading = false);
      return;
    }

    bool success = await _apiService.createBooking(
      kosId: widget.kos.id,
      userId: userId,
      checkIn: DateFormat('yyyy-MM-dd').format(_selectedDate),
      duration: _duration.toString(),
      totalPrice: totalPrice.toString(),
    );

    setState(() => _isBookingLoading = false);

    if (success) {
      Navigator.pop(context); 
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text("Booking Berhasil! Silakan selesaikan pembayaran."),
          backgroundColor: Colors.green,
          duration: Duration(seconds: 2),
        )
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Gagal melakukan booking.")));
    }
  }
}