import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'models.dart';

class ApiService {
  // GANTI IP DI SINI (Pastikan sama dengan laptop Anda)
  static const String baseUrl = 'http://192.168.1.27/marikos_api';

  // ===========================================================================
  // 1. SESSION MANAGEMENT (LOGIN & USER DATA)
  // ===========================================================================

  Future<void> saveUserSession(User user) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('user_id', user.id);
    await prefs.setString('user_name', user.name);
    await prefs.setString('user_email', user.email);
    await prefs.setString('user_phone', user.phone);
    await prefs.setString('user_role', user.role);
  }

  Future<String?> getCurrentUserId() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('user_id');
  }

  Future<User?> getCurrentUser() async {
    final prefs = await SharedPreferences.getInstance();
    final id = prefs.getString('user_id');
    if (id == null) return null;

    return User(
      id: id,
      name: prefs.getString('user_name') ?? '',
      email: prefs.getString('user_email') ?? '',
      phone: prefs.getString('user_phone') ?? '',
      role: prefs.getString('user_role') ?? 'user',
    );
  }

  Future<void> logout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
  }

  Future<User?> login(String email, String password) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/login.php'),
        body: {'email': email, 'password': password},
      );

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['success'] == true) {
          final user = User.fromJson(data['user']);
          await saveUserSession(user);
          return user;
        }
      }
    } catch (e) {
      print("Error Login: $e");
    }
    return null;
  }

  // Tambahan: Get User Profile (Optional jika butuh refresh data dari server)
  Future<User?> getUserProfile(String userId) async {
    // Implementasi sederhana mengambil data user dari server jika diperlukan
    // Saat ini getCurrentUser() dari SharedPrefs sudah cukup untuk sesi lokal
    return getCurrentUser();
  }

  // ===========================================================================
  // 2. FITUR KOS (HOME & SEARCH)
  // ===========================================================================

  Future<List<Kos>> getKos() async {
    try {
      final response = await http.get(Uri.parse('$baseUrl/get_kos.php'));
      if (response.statusCode == 200) {
        final List<dynamic> jsonResponse = json.decode(response.body);
        return jsonResponse.map((data) => Kos.fromJson(data)).toList();
      }
    } catch (e) {
      print("Error Get Kos: $e");
    }
    return [];
  }

  // ===========================================================================
  // 3. FITUR BOOKING
  // ===========================================================================

  Future<bool> createBooking({
    required String kosId,
    required String userId,
    required String checkIn,
    required String duration,
    required String totalPrice,
  }) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/booking.php'),
        body: {
          'kos_id': kosId,
          'user_id': userId,
          'check_in': checkIn,
          'duration': duration,
          'total_price': totalPrice,
        },
      );

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        return data['success'] == true;
      }
    } catch (e) {
      print("Error Booking: $e");
    }
    return false;
  }

  Future<List<Booking>> getUserBookings() async {
    final userId = await getCurrentUserId();
    if (userId == null) return [];

    try {
      final response = await http.get(
        Uri.parse('$baseUrl/read_booking.php?user_id=$userId')
      );
      if (response.statusCode == 200) {
        final List<dynamic> jsonResponse = json.decode(response.body);
        return jsonResponse.map((data) => Booking.fromJson(data)).toList();
      }
    } catch (e) {
      print("Error Get Bookings: $e");
    }
    return [];
  }

  // ===========================================================================
  // 4. FITUR PEMILIK (TAMBAH KOS)
  // ===========================================================================

  Future<bool> addKos({
    required String nama,
    required String harga,
    required String fasilitas,
    required String alamat,
    required String jenis,
    required String deskripsi,
    required String imagePath,
  }) async {
    try {
      final userName = (await getCurrentUser())?.name ?? 'Pemilik';
      
      var request = http.MultipartRequest('POST', Uri.parse('$baseUrl/create_kos.php'));
      request.fields['nama'] = nama;
      request.fields['harga'] = harga;
      request.fields['fasilitas'] = fasilitas;
      request.fields['alamat'] = alamat;
      request.fields['jenis_kos'] = jenis;
      request.fields['pemilik'] = userName;

      if (imagePath.isNotEmpty) {
        request.files.add(await http.MultipartFile.fromPath('foto', imagePath));
      }

      var response = await request.send();
      if (response.statusCode == 200) return true;
    } catch (e) {
      print("Error Add Kos: $e");
    }
    return false;
  }

  // ===========================================================================
  // 5. FITUR CHAT
  // ===========================================================================

  Future<List<Map<String, dynamic>>> getChatRooms(String userId) async {
    try {
      final response = await http.get(Uri.parse('$baseUrl/get_chat_rooms.php?user_id=$userId'));
      if (response.statusCode == 200) {
        return List<Map<String, dynamic>>.from(json.decode(response.body));
      }
    } catch (e) {
      print("Error Chat Rooms: $e");
    }
    return [];
  }

  Future<List<Message>> getMessages(String userId, String otherId) async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/get_messages.php?user_id=$userId&other_id=$otherId'),
      );
      if (response.statusCode == 200) {
        final List<dynamic> jsonResponse = json.decode(response.body);
        return jsonResponse.map((data) => Message.fromJson(data)).toList();
      }
    } catch (e) {
      print("Error Get Messages: $e");
    }
    return [];
  }

  Future<bool> sendMessage(String senderId, String receiverId, String content) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/send_message.php'),
        body: {
          'sender_id': senderId,
          'receiver_id': receiverId,
          'message': content,
        },
      );
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        return data['success'] == true;
      }
    } catch (e) {
      print("Error Send Message: $e");
    }
    return false;
  }

// --- UPDATE STATUS BOOKING (PEMBAYARAN) ---
  Future<bool> updateBookingStatus(String bookingId) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/pay_booking.php'),
        body: {'booking_id': bookingId},
      );
      if (response.statusCode == 200) {
        return json.decode(response.body)['success'] == true;
      }
    } catch (e) {
      print("Error Pay Booking: $e");
    }
    return false;
  }

  // --- AMBIL KOS MILIK SENDIRI ---
  Future<List<Kos>> getMyKos() async {
    final user = await getCurrentUser();
    if (user == null) return [];

    try {
      // Filter berdasarkan Nama Pemilik sesuai struktur DB Anda
      final response = await http.get(
        Uri.parse('$baseUrl/get_my_kos.php?pemilik=${user.name}')
      );
      if (response.statusCode == 200) {
        final List<dynamic> jsonResponse = json.decode(response.body);
        return jsonResponse.map((data) => Kos.fromJson(data)).toList();
      }
    } catch (e) {
      print("Error Get My Kos: $e");
    }
    return [];
  }

  // --- DELETE KOS ---
  Future<bool> deleteKos(String kosId) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/delete_kos.php'),
        body: {'id': kosId},
      );
      if (response.statusCode == 200) {
        return json.decode(response.body)['success'] == true;
      }
    } catch (e) {
      print("Error Delete Kos: $e");
    }
    return false;
  }

  // --- UPDATE KOS ---
  Future<bool> updateKos({
    required String id,
    required String nama,
    required String harga,
    required String fasilitas,
    required String alamat,
    required String jenis,
    String? imagePath, // Opsional jika tidak ganti gambar
  }) async {
    try {
      final userName = (await getCurrentUser())?.name ?? 'Pemilik';
      
      var request = http.MultipartRequest('POST', Uri.parse('$baseUrl/update_kos.php'));
      request.fields['id'] = id;
      request.fields['nama'] = nama;
      request.fields['harga'] = harga;
      request.fields['fasilitas'] = fasilitas;
      request.fields['alamat'] = alamat;
      request.fields['jenis_kos'] = jenis;
      request.fields['pemilik'] = userName;
      request.fields['status'] = 'tersedia';

      if (imagePath != null && imagePath.isNotEmpty) {
        request.files.add(await http.MultipartFile.fromPath('foto', imagePath));
      }

      var response = await request.send();
      if (response.statusCode == 200) return true;
    } catch (e) {
      print("Error Update Kos: $e");
    }
    return false;
  }
// --- AMBIL BOOKING MASUK (PESANAN DARI PENYEWA) ---
Future<List<Booking>> getIncomingBookings() async {
    final user = await getCurrentUser();
    if (user == null) return [];

    try {
      // WAJIB: Encode nama agar spasi terbaca (Budi Santoso -> Budi%20Santoso)
      String encodedName = Uri.encodeComponent(user.name);

      final response = await http.get(
        Uri.parse('$baseUrl/get_incoming_bookings.php?pemilik=$encodedName')
      );
      
      if (response.statusCode == 200) {
        final List<dynamic> jsonResponse = json.decode(response.body);
        return jsonResponse.map((data) => Booking.fromJson(data)).toList();
      }
    } catch (e) {
      print("Error Incoming Bookings: $e");
    }
    return [];
  }
 // --- REGISTER (UPDATE: Hapus parameter role) ---
  Future<String> register(String nama, String email, String password, String phone) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/register.php'),
        body: {
          'nama': nama,
          'email': email,
          'password': password,
          'no_hp': phone,
          // 'role': role, <--- HAPUS BARIS INI (Sudah diatur di PHP)
        },
      );

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['success'] == true) {
          return "OK";
        } else {
          return data['message'] ?? "Gagal mendaftar";
        }
      }
    } catch (e) {
      return "Error Koneksi: $e";
    }
    return "Terjadi kesalahan server";
  }
  }
  