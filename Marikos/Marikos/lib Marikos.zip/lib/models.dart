import 'package:flutter/material.dart';

// ==========================================
// MODEL USER (SUDAH DIPERBAIKI: ADA PHONE)
// ==========================================
class User {
  final String id;
  final String name;
  final String email;
  final String role; // 'admin', 'pemilik', 'pencari'
  final String phone; // <--- KEMBALIKAN FIELD INI

  User({
    required this.id,
    required this.name,
    required this.email,
    required this.role,
    required this.phone, // <--- TAMBAHKAN DI CONSTRUCTOR
  });

  factory User.fromJson(Map<String, dynamic> json) {
    return User(
      id: json['id'].toString(),
      name: json['nama'] ?? json['name'] ?? '',
      email: json['email'] ?? '',
      role: json['role'] ?? 'pencari',
      // Baca phone dari berbagai kemungkinan key database
      phone: json['phone'] ?? json['no_hp'] ?? json['telepon'] ?? '', 
    );
  }
}

// ==========================================
// MODEL KOS (TETAP SAMA SEPERTI YANG BERHASIL TADI)
// ==========================================
class Kos {
  final String id;
  final String name;
  final String location;
  final String address;
  final double price;
  final String type;
  final String description;
  final List<String> images;
  final List<String> facilities;
  final double rating;
  final int reviewCount;
  final String ownerName;
  final String ownerId;
  final bool isAvailable;
  final double latitude;
  final double longitude;

  Kos({
    required this.id,
    required this.name,
    required this.location,
    required this.address,
    required this.price,
    required this.type,
    required this.description,
    required this.images,
    required this.facilities,
    required this.rating,
    required this.reviewCount,
    required this.ownerName,
    required this.ownerId,
    required this.isAvailable,
    required this.latitude,
    required this.longitude,
  });

  factory Kos.fromJson(Map<String, dynamic> json) {
    // Helper untuk konversi list gambar
    List<String> parseImages() {
      if (json['images'] != null && json['images'] is List) {
        return (json['images'] as List).map((e) => e.toString()).toList();
      } else if (json['foto_url'] != null) {
        return [json['foto_url'].toString()];
      }
      return [];
    }

    // Helper untuk konversi fasilitas
    List<String> parseFacilities() {
      if (json['facilities'] != null && json['facilities'] is List) {
        return (json['facilities'] as List).map((e) => e.toString()).toList();
      } else if (json['fasilitas'] != null) {
        return json['fasilitas'].toString().split(',').map((e) => e.trim()).toList();
      }
      return [];
    }

    return Kos(
      id: json['id'].toString(),
      name: json['name'] ?? json['nama'] ?? 'Tanpa Nama',
      location: json['location'] ?? 'Bandung',
      address: json['address'] ?? json['alamat'] ?? '',
      price: double.tryParse(json['price']?.toString() ?? json['harga']?.toString() ?? '0') ?? 0.0,
      type: json['type'] ?? json['jenis_kos'] ?? 'campur',
      description: json['description'] ?? json['fasilitas'] ?? '',
      images: parseImages(),
      facilities: parseFacilities(),
      rating: double.tryParse(json['rating']?.toString() ?? '0') ?? 0.0,
      reviewCount: int.tryParse(json['review_count']?.toString() ?? '0') ?? 0,
      ownerName: json['owner_name'] ?? json['pemilik'] ?? '',
      ownerId: json['owner_id']?.toString() ?? '0',
      isAvailable: (json['is_available'] == true) || (json['status'] == 'tersedia'),
      latitude: double.tryParse(json['latitude']?.toString() ?? '-6.9175') ?? -6.9175,
      longitude: double.tryParse(json['longitude']?.toString() ?? '107.6191') ?? 107.6191,
    );
  }
}

// ==========================================
// MODEL BOOKING
// ==========================================
class Booking {
  final String id;
  final String userId;
  final String kosId;
  final String kosName;     
  final String userName;    
  final DateTime checkInDate;
  final DateTime checkOutDate;
  final double totalPrice;
  final String status;

  Booking({
    required this.id,
    required this.userId,
    required this.kosId,
    required this.kosName,
    required this.userName, 
    required this.checkInDate,
    required this.checkOutDate,
    required this.totalPrice,
    required this.status,
  });

  factory Booking.fromJson(Map<String, dynamic> json) {
    DateTime checkIn = DateTime.tryParse(json['tanggal_masuk'] ?? '') ?? DateTime.now();
    int duration = int.tryParse(json['lama_sewa']?.toString() ?? '1') ?? 1;
    DateTime checkOut = DateTime(checkIn.year, checkIn.month + duration, checkIn.day);

    return Booking(
      id: json['id'].toString(),
      userId: json['user_id'].toString(),
      kosId: json['kos_id'].toString(),
      kosName: json['nama_kos'] ?? 'Kos',
      userName: json['user_name'] ?? json['penyewa'] ?? 'Penyewa',
      checkInDate: checkIn,
      checkOutDate: checkOut,
      totalPrice: double.tryParse(json['total_harga']?.toString() ?? '0') ?? 0.0,
      status: json['status'] ?? 'pending',
    );
  }
}

// ==========================================
// MODEL MESSAGE
// ==========================================
class Message {
  final String id;
  final String senderId;
  final String receiverId;
  final String content;
  final DateTime timestamp;
  final bool isRead;

  Message({
    required this.id,
    required this.senderId,
    required this.receiverId,
    required this.content,
    required this.timestamp,
    required this.isRead,
  });

  factory Message.fromJson(Map<String, dynamic> json) {
    return Message(
      id: json['id'].toString(),
      senderId: json['sender_id'].toString(),
      receiverId: json['receiver_id'].toString(),
      content: json['message'] ?? '',
      timestamp: DateTime.tryParse(json['created_at'].toString()) ?? DateTime.now(),
      isRead: json['is_read'] == 1 || json['is_read'] == '1',
    );
  }
}