import 'package:flutter/material.dart';
import 'package:intl/intl.dart'; // Pastikan intl ada di pubspec.yaml
import 'models.dart';
import 'api_service.dart'; // Import ApiService
import 'kos_detail_page.dart';

class SearchPage extends StatefulWidget {
  @override
  _SearchPageState createState() => _SearchPageState();
}

class _SearchPageState extends State<SearchPage> {
  final _searchController = TextEditingController();
  final ApiService _apiService = ApiService(); // Inisialisasi API Service
  
  List<Kos> _allKos = []; // Menyimpan semua data dari database
  List<Kos> _filteredKos = []; // Menyimpan data yang sedang ditampilkan (hasil filter)
  
  String _selectedLocation = 'Semua Lokasi';
  String _selectedType = 'Semua Tipe';
  double _maxPrice = 5000000; // Default max price dinaikkan agar mencakup lebih banyak kos
  bool _isLoading = false;

  final List<String> _locations = [
    'Semua Lokasi',
    'Karawang',
    'Jakarta',
    'Bandung',
    'Bekasi',
  ];
  final List<String> _types = ['Semua Tipe', 'putra', 'putri', 'campur'];

  @override
  void initState() {
    super.initState();
    _loadKosData();
  }

  // Fungsi baru untuk mengambil data dari API
  Future<void> _loadKosData() async {
    setState(() {
      _isLoading = true;
    });

    try {
      final List<Kos> kosList = await _apiService.getKos();
      
      if (mounted) {
        setState(() {
          _allKos = kosList;
          _filteredKos = kosList;
          _isLoading = false;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  void _filterKos() {
    setState(() {
      _filteredKos = _allKos.where((kos) {
        // Filter Text (Nama atau Lokasi)
        final matchesSearch =
            _searchController.text.isEmpty ||
            kos.name.toLowerCase().contains(
              _searchController.text.toLowerCase(),
            ) ||
            kos.location.toLowerCase().contains(
              _searchController.text.toLowerCase(),
            );

        // Filter Lokasi Dropdown
        // Note: Pastikan data lokasi di database persis sama dengan list _locations
        // atau gunakan logic contains/toLowerCase agar lebih fleksibel
        final matchesLocation =
            _selectedLocation == 'Semua Lokasi' ||
            kos.location.toLowerCase().contains(_selectedLocation.toLowerCase()) ||
            _selectedLocation.toLowerCase().contains(kos.location.toLowerCase());

        // Filter Tipe
        final matchesType =
            _selectedType == 'Semua Tipe' || kos.type.toLowerCase() == _selectedType.toLowerCase();

        // Filter Harga
        final matchesPrice = kos.price <= _maxPrice;

        return matchesSearch && matchesLocation && matchesType && matchesPrice;
      }).toList();
    });
  }

  void _clearFilters() {
    setState(() {
      _searchController.clear();
      _selectedLocation = 'Semua Lokasi';
      _selectedType = 'Semua Tipe';
      _maxPrice = 5000000;
      _filteredKos = List.from(_allKos); // Reset ke semua data yang sudah di-fetch
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Cari Kos'),
        backgroundColor: Colors.purple.shade700,
        foregroundColor: Colors.white,
      ),
      body: Column(
        children: [
          // Filter Section
          _buildFilterSection(),

          // Results Section
          Expanded(
            child: _isLoading
                ? Center(child: CircularProgressIndicator())
                : _filteredKos.isEmpty
                ? _buildEmptyState()
                : _buildKosList(),
          ),
        ],
      ),
    );
  }

  Widget _buildFilterSection() {
    return Card(
      margin: EdgeInsets.all(16),
      elevation: 4,
      child: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          children: [
            // Search Bar
            TextField(
              controller: _searchController,
              decoration: InputDecoration(
                hintText: 'Cari berdasarkan nama atau lokasi...',
                prefixIcon: Icon(Icons.search),
                border: OutlineInputBorder(),
                suffixIcon: _searchController.text.isNotEmpty
                    ? IconButton(
                        icon: Icon(Icons.clear),
                        onPressed: () {
                          _searchController.clear();
                          _filterKos();
                        },
                      )
                    : null,
              ),
              onChanged: (value) => _filterKos(),
            ),
            SizedBox(height: 16),

            // Location and Type Filters
            Row(
              children: [
                Expanded(
                  child: DropdownButtonFormField<String>(
                    value: _selectedLocation,
                    items: _locations
                        .map(
                          (location) => DropdownMenuItem(
                            value: location,
                            child: Text(
                              location, 
                              style: TextStyle(fontSize: 13),
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        )
                        .toList(),
                    onChanged: (value) {
                      setState(() {
                        _selectedLocation = value!;
                        _filterKos();
                      });
                    },
                    decoration: InputDecoration(
                      labelText: 'Lokasi',
                      border: OutlineInputBorder(),
                      contentPadding: EdgeInsets.symmetric(horizontal: 10, vertical: 0),
                    ),
                    isExpanded: true,
                  ),
                ),
                SizedBox(width: 16),
                Expanded(
                  child: DropdownButtonFormField<String>(
                    value: _selectedType,
                    items: _types
                        .map(
                          (type) => DropdownMenuItem(
                            value: type,
                            child: Text(
                              type == 'putra'
                                  ? 'Putra'
                                  : type == 'putri'
                                  ? 'Putri'
                                  : type == 'campur'
                                  ? 'Campur'
                                  : 'Semua',
                               style: TextStyle(fontSize: 13),
                            ),
                          ),
                        )
                        .toList(),
                    onChanged: (value) {
                      setState(() {
                        _selectedType = value!;
                        _filterKos();
                      });
                    },
                    decoration: InputDecoration(
                      labelText: 'Tipe',
                      border: OutlineInputBorder(),
                      contentPadding: EdgeInsets.symmetric(horizontal: 10, vertical: 0),
                    ),
                  ),
                ),
              ],
            ),
            SizedBox(height: 16),

            // Price Filter
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Harga Maksimal: Rp ${NumberFormat.decimalPattern('id').format(_maxPrice)}',
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
                Slider(
                  value: _maxPrice,
                  min: 0,
                  max: 10000000, // Range sampai 10 Juta
                  divisions: 100,
                  label: NumberFormat.compactCurrency(locale: 'id', symbol: 'Rp', decimalDigits: 0).format(_maxPrice),
                  onChanged: (value) {
                    setState(() {
                      _maxPrice = value;
                      _filterKos();
                    });
                  },
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [Text('Rp 0'), Text('Rp 10jt+')],
                ),
              ],
            ),
            SizedBox(height: 8),

            // Clear Filters Button
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                OutlinedButton.icon(
                  onPressed: _clearFilters,
                  icon: Icon(Icons.refresh, size: 16),
                  label: Text('Reset Filter'),
                  style: OutlinedButton.styleFrom(
                    visualDensity: VisualDensity.compact,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildKosList() {
    return ListView.builder(
      padding: EdgeInsets.symmetric(horizontal: 16),
      itemCount: _filteredKos.length,
      itemBuilder: (context, index) {
        final kos = _filteredKos[index];
        return _buildKosListItem(kos);
      },
    );
  }

  Widget _buildKosListItem(Kos kos) {
    return Card(
      margin: EdgeInsets.only(bottom: 12),
      elevation: 2,
      child: InkWell(
        onTap: () {
          // Navigasi ke detail
          Navigator.pushNamed(context, '/kos-detail', arguments: kos);
        },
        child: Padding(
          padding: EdgeInsets.all(16),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Kos Image
              Container(
                width: 80,
                height: 80,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(8),
                ),
                child: kos.images.isNotEmpty
                    ? ClipRRect(
                        borderRadius: BorderRadius.circular(8),
                        child: Image.network(
                          kos.images[0],
                          fit: BoxFit.cover,
                          errorBuilder: (context, error, stackTrace) {
                            return Container(
                              color: Colors.grey.shade300,
                              child: Center(
                                child: Icon(
                                  Icons.broken_image,
                                  color: Colors.grey.shade600,
                                ),
                              ),
                            );
                          },
                        ),
                      )
                    : Container(
                        color: Colors.grey.shade300,
                        child: Center(
                          child: Icon(
                            Icons.home_work,
                            color: Colors.grey.shade600,
                          ),
                        ),
                      ),
              ),
              SizedBox(width: 16),

              // Kos Info
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Expanded(
                          child: Text(
                            kos.name,
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                            ),
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                        Container(
                          padding: EdgeInsets.symmetric(
                            horizontal: 8,
                            vertical: 4,
                          ),
                          decoration: BoxDecoration(
                            color: _getTypeColor(kos.type),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Text(
                            kos.type.toUpperCase(),
                            style: TextStyle(
                              fontSize: 10,
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 4),
                    Row(
                      children: [
                        Icon(Icons.location_on, size: 14, color: Colors.grey),
                        SizedBox(width: 4),
                        Expanded(
                          child: Text(
                            kos.location,
                            style: TextStyle(color: Colors.grey.shade600),
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 8),
                    // Fasilitas (Max 3)
                    Wrap(
                      spacing: 4,
                      runSpacing: 4,
                      children: kos.facilities
                          .take(3)
                          .map(
                            (facility) => Container(
                              padding: EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                              decoration: BoxDecoration(
                                color: Colors.purple.shade50,
                                borderRadius: BorderRadius.circular(4),
                                border: Border.all(color: Colors.purple.shade100),
                              ),
                              child: Text(
                                facility, 
                                style: TextStyle(fontSize: 10, color: Colors.purple.shade700),
                              ),
                            ),
                          )
                          .toList(),
                    ),
                    SizedBox(height: 8),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          'Rp ${NumberFormat.decimalPattern('id').format(kos.price)} / bln',
                          style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.bold,
                            color: Colors.green.shade700,
                          ),
                        ),
                        Row(
                          children: [
                            Icon(Icons.star, color: Colors.amber, size: 16),
                            SizedBox(width: 4),
                            Text(kos.rating.toString(), style: TextStyle(fontSize: 12)),
                          ],
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.search_off, size: 64, color: Colors.grey.shade400),
            SizedBox(height: 16),
            Text(
              'Tidak ada kos yang ditemukan',
              style: TextStyle(fontSize: 18, color: Colors.grey.shade600),
            ),
            SizedBox(height: 8),
            Text(
              'Coba ubah filter pencarian Anda',
              style: TextStyle(color: Colors.grey.shade500),
            ),
            SizedBox(height: 16),
            ElevatedButton(
              onPressed: _clearFilters,
              child: Text('Hapus Semua Filter'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.purple.shade700,
                foregroundColor: Colors.white,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Color _getTypeColor(String type) {
    switch (type.toLowerCase()) {
      case 'putra':
        return Colors.purple.shade700;
      case 'putri':
        return Colors.pink.shade700;
      case 'campur':
        return Colors.deepPurple.shade700;
      default:
        return Colors.grey;
    }
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }
}