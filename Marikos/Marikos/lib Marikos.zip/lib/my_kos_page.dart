import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'api_service.dart';
import 'models.dart';
import 'edit_kos_page.dart'; // Pastikan file ini ada
import 'add_kos_page.dart';  // Pastikan file ini ada

class MyKosPage extends StatefulWidget {
  @override
  _MyKosPageState createState() => _MyKosPageState();
}

class _MyKosPageState extends State<MyKosPage> {
  final ApiService _apiService = ApiService();
  late Future<List<Kos>> _myKosFuture;

  @override
  void initState() {
    super.initState();
    _refreshData();
  }

  // Fungsi untuk memuat ulang data dari server
  void _refreshData() {
    setState(() {
      _myKosFuture = _apiService.getMyKos();
    });
  }

  // Fungsi Menghapus Kos
  void _deleteItem(String id) async {
    // Tampilkan Dialog Konfirmasi
    bool confirm = await showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text("Hapus Kos?"),
        content: Text("Data yang dihapus tidak bisa dikembalikan."),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: Text("Batal"),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true),
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            child: Text("Hapus"),
          ),
        ],
      ),
    ) ?? false;

    // Jika user pilih Hapus
    if (confirm) {
      bool success = await _apiService.deleteKos(id);
      if (success) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Berhasil dihapus"), backgroundColor: Colors.green)
        );
        _refreshData(); // Refresh list otomatis
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Gagal menghapus"), backgroundColor: Colors.red)
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade50,
      appBar: AppBar(
        title: Text("Kelola Kos Saya"),
        backgroundColor: Colors.purple.shade700,
        foregroundColor: Colors.white,
        elevation: 0,
      ),
      
      // TOMBOL TAMBAH KOS (Floating Action Button)
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () async {
          // Buka halaman tambah kos
          await Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => AddKosPage()),
          );
          // Saat kembali, refresh data
          _refreshData(); 
        },
        label: Text("Tambah Kos"),
        icon: Icon(Icons.add),
        backgroundColor: Colors.purple.shade700,
      ),
      
      body: FutureBuilder<List<Kos>>(
        future: _myKosFuture,
        builder: (context, snapshot) {
          // State 1: Loading
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          }
          
          // State 2: Error
          if (snapshot.hasError) {
            return Center(child: Text("Terjadi kesalahan memuat data."));
          }

          // State 3: Data Kosong
          if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.house_siding, size: 80, color: Colors.grey.shade300),
                  SizedBox(height: 16),
                  Text("Anda belum memiliki properti kos.", style: TextStyle(color: Colors.grey)),
                  SizedBox(height: 8),
                  Text("Tekan tombol + untuk mulai menyewakan.", style: TextStyle(color: Colors.grey, fontSize: 12)),
                ],
              ),
            );
          }

          // State 4: Ada Data (List)
          return ListView.builder(
            // Tambahkan padding bawah agar list paling bawah tidak tertutup tombol tambah
            padding: EdgeInsets.fromLTRB(16, 16, 16, 80), 
            itemCount: snapshot.data!.length,
            itemBuilder: (context, index) {
              final kos = snapshot.data![index];
              return _buildKosItem(kos);
            },
          );
        },
      ),
    );
  }

  Widget _buildKosItem(Kos kos) {
    return Card(
      margin: EdgeInsets.only(bottom: 16),
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Column(
        children: [
          // Bagian Atas: Gambar & Info Dasar
          ListTile(
            contentPadding: EdgeInsets.all(12),
            leading: ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: Container(
                width: 60,
                height: 60,
                color: Colors.grey.shade200,
                child: kos.images.isNotEmpty
                    ? Image.network(
                        kos.images[0],
                        fit: BoxFit.cover,
                        errorBuilder: (c,e,s) => Icon(Icons.broken_image, color: Colors.grey),
                      )
                    : Icon(Icons.home, color: Colors.grey),
              ),
            ),
            title: Text(
              kos.name,
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
              maxLines: 1, overflow: TextOverflow.ellipsis,
            ),
            subtitle: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(height: 4),
                Text(
                  "Rp ${NumberFormat('#,###', 'id_ID').format(kos.price)} / bulan",
                  style: TextStyle(color: Colors.purple.shade700, fontWeight: FontWeight.bold),
                ),
                SizedBox(height: 4),
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                  decoration: BoxDecoration(
                    color: Colors.grey.shade200,
                    borderRadius: BorderRadius.circular(4)
                  ),
                  child: Text(
                    kos.type.toUpperCase(),
                    style: TextStyle(fontSize: 10, color: Colors.grey.shade800),
                  ),
                )
              ],
            ),
          ),
          
          Divider(height: 1),
          
          // Bagian Bawah: Tombol Aksi (Edit & Hapus)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8.0, vertical: 4),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                TextButton.icon(
                  onPressed: () async {
                    // Navigasi ke halaman Edit
                    await Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => EditKosPage(kos: kos)),
                    );
                    _refreshData(); // Refresh setelah edit
                  },
                  icon: Icon(Icons.edit, size: 18, color: Colors.blue),
                  label: Text("Edit", style: TextStyle(color: Colors.blue)),
                ),
                SizedBox(width: 8),
                TextButton.icon(
                  onPressed: () => _deleteItem(kos.id),
                  icon: Icon(Icons.delete, size: 18, color: Colors.red),
                  label: Text("Hapus", style: TextStyle(color: Colors.red)),
                ),
              ],
            ),
          )
        ],
      ),
    );
  }
}