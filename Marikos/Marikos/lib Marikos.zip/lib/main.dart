import 'package:flutter/material.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'login_page.dart';
import 'home_page.dart';
import 'search_page.dart';
import 'kos_detail_page.dart';
import 'booking_page.dart';
import 'chat_page.dart';
import 'profile_page.dart';
import 'models.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await initializeDateFormatting('id_ID', null);

  runApp(MariKosApp());
}

class MariKosApp extends StatelessWidget {
  const MariKosApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'MariKos',
      theme: ThemeData(
        primarySwatch: Colors.purple,
        visualDensity: VisualDensity.adaptivePlatformDensity,
        fontFamily: 'Poppins',
      ),
      initialRoute: '/login',
      routes: {
        '/login': (context) => LoginPage(),
        '/home': (context) => HomePage(),
        '/search': (context) => SearchPage(),
        '/kos-detail': (context) {
          final kos = ModalRoute.of(context)!.settings.arguments as Kos;
          return KosDetailPage(kos: kos);
        },
        '/booking': (context) {
          final kos = ModalRoute.of(context)!.settings.arguments as Kos;
          return BookingPage(kos: kos);
        },
        '/chat': (context) {
          final chatArgs =
              ModalRoute.of(context)!.settings.arguments
                  as Map<String, dynamic>;
          return ChatPage(
            receiverId: chatArgs['receiverId'],
            receiverName: chatArgs['receiverName'],
          );
        },
        '/profile': (context) => ProfilePage(),
      },
      debugShowCheckedModeBanner: false,
    );
  }
}