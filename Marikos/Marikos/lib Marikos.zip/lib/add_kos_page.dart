import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'api_service.dart';

class AddKosPage extends StatefulWidget {
  @override
  _AddKosPageState createState() => _AddKosPageState();
}

class _AddKosPageState extends State<AddKosPage> {
  final _formKey = GlobalKey<FormState>();
  final _namaController = TextEditingController();
  final _hargaController = TextEditingController();
  final _alamatController = TextEditingController();
  final _fasilitasController = TextEditingController();
  
  String _jenisKos = 'putra';
  File? _imageFile;
  bool _isLoading = false;

  Future<void> _pickImage() async {
    final picked = await ImagePicker().pickImage(source: ImageSource.gallery);
    if (picked != null) {
      setState(() {
        _imageFile = File(picked.path);
      });
    }
  }

  void _submit() async {
    if (_formKey.currentState!.validate() && _imageFile != null) {
      setState(() => _isLoading = true);
      
      bool success = await ApiService().addKos(
        nama: _namaController.text,
        harga: _hargaController.text,
        alamat: _alamatController.text,
        fasilitas: _fasilitasController.text,
        jenis: _jenisKos,
        deskripsi: "Kos nyaman", 
        imagePath: _imageFile!.path,
      );

      setState(() => _isLoading = false);

      if (success) {
        Navigator.pop(context); 
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Kos Berhasil Ditambahkan!")));
      } else {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Gagal upload kos")));
      }
    } else if (_imageFile == null) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Pilih foto terlebih dahulu")));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Tambah Kos Baru")),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              GestureDetector(
                onTap: _pickImage,
                child: Container(
                  height: 150,
                  width: double.infinity,
                  color: Colors.grey.shade200,
                  child: _imageFile != null
                      ? Image.file(_imageFile!, fit: BoxFit.cover)
                      : Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [Icon(Icons.camera_alt), Text("Upload Foto Kos")],
                        ),
                ),
              ),
              SizedBox(height: 16),
              TextFormField(controller: _namaController, decoration: InputDecoration(labelText: "Nama Kos"), validator: (v) => v!.isEmpty ? "Isi nama" : null),
              TextFormField(controller: _hargaController, decoration: InputDecoration(labelText: "Harga"), keyboardType: TextInputType.number, validator: (v) => v!.isEmpty ? "Isi harga" : null),
              TextFormField(controller: _alamatController, decoration: InputDecoration(labelText: "Alamat"), validator: (v) => v!.isEmpty ? "Isi alamat" : null),
              TextFormField(controller: _fasilitasController, decoration: InputDecoration(labelText: "Fasilitas")),
              DropdownButtonFormField<String>(
                value: _jenisKos,
                items: ['putra', 'putri', 'campur'].map((e) => DropdownMenuItem(value: e, child: Text(e.toUpperCase()))).toList(),
                onChanged: (v) => setState(() => _jenisKos = v!),
                decoration: InputDecoration(labelText: "Jenis Kos"),
              ),
              SizedBox(height: 20),
              ElevatedButton(onPressed: _isLoading ? null : _submit, child: _isLoading ? CircularProgressIndicator() : Text("Simpan"))
            ],
          ),
        ),
      ),
    );
  }
}