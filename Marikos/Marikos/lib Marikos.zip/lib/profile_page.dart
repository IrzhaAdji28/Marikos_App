import 'package:flutter/material.dart';
import 'models.dart';
import 'api_service.dart';
import 'my_kos_page.dart'; // Menu Kelola Kos
import 'manage_booking_page.dart'; // Menu Kelola Booking Masuk

class ProfilePage extends StatefulWidget {
  @override
  _ProfilePageState createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  final ApiService _apiService = ApiService();
  User? _user;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadUserProfile();
  }

  void _loadUserProfile() async {
    final user = await _apiService.getCurrentUser();
    if (mounted) {
      setState(() {
        _user = user;
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) return Center(child: CircularProgressIndicator());
    if (_user == null) return Center(child: Text("Silakan Login"));

    return Scaffold(
      backgroundColor: Colors.grey.shade50, // Background agak abu
      appBar: AppBar(
        title: Text('Profil Pengguna'),
        backgroundColor: Colors.purple.shade700,
        foregroundColor: Colors.white,
        automaticallyImplyLeading: false,
        elevation: 0,
      ),
      body: Column(
        children: [
          // BAGIAN ATAS: HEADER PROFIL
          Container(
            padding: EdgeInsets.only(bottom: 24),
            decoration: BoxDecoration(
              color: Colors.purple.shade700,
              borderRadius: BorderRadius.vertical(bottom: Radius.circular(24)),
            ),
            child: Center(
              child: Column(
                children: [
                  CircleAvatar(
                    radius: 40,
                    backgroundColor: Colors.white,
                    child: Text(
                      _user!.name[0].toUpperCase(),
                      style: TextStyle(fontSize: 32, fontWeight: FontWeight.bold, color: Colors.purple),
                    ),
                  ),
                  SizedBox(height: 12),
                  Text(
                    _user!.name,
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white),
                  ),
                  Text(
                    _user!.email,
                    style: TextStyle(color: Colors.purple.shade100),
                  ),
                  SizedBox(height: 8),
                  Container(
                    padding: EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                    decoration: BoxDecoration(
                      color: Colors.white24,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Text(
                      "Role: ${_user!.role.toUpperCase()}",
                      style: TextStyle(fontSize: 12, color: Colors.white),
                    ),
                  ),
                ],
              ),
            ),
          ),
          
          // BAGIAN TENGAH: MENU
          Expanded(
            child: ListView(
              padding: EdgeInsets.all(16),
              children: [
                // MENU 1: Kelola Kos Saya (Di dalamnya ada tombol tambah)
                _buildMenuCard(
                  icon: Icons.store,
                  color: Colors.orange,
                  title: "Kelola Kos Saya",
                  subtitle: "Lihat & Tambah properti Anda",
                  onTap: () {
                    Navigator.push(context, MaterialPageRoute(builder: (c) => MyKosPage()));
                  },
                ),
                SizedBox(height: 12),

                // MENU 2: Kelola Booking (Ganti Riwayat Pemesanan)
                _buildMenuCard(
                  icon: Icons.assignment_turned_in,
                  color: Colors.blue,
                  title: "Kelola Booking", 
                  subtitle: "Cek pesanan masuk dari penyewa",
                  onTap: () {
                    Navigator.push(context, MaterialPageRoute(builder: (c) => ManageBookingPage()));
                  },
                ),
                
                // Opsional: Jika Anda masih ingin user bisa melihat riwayat booking *PRIBADI* mereka sendiri
                // Anda bisa menambahkan menu "Pesanan Saya" di sini.
              ],
            ),
          ),

          // BAGIAN BAWAH: TOMBOL KELUAR
          Padding(
            padding: EdgeInsets.all(16),
            child: SizedBox(
              width: double.infinity,
              height: 50,
              child: OutlinedButton.icon(
                onPressed: () => _showLogoutDialog(context),
                icon: Icon(Icons.logout, color: Colors.red),
                label: Text("Keluar Aplikasi"),
                style: OutlinedButton.styleFrom(
                  foregroundColor: Colors.red,
                  side: BorderSide(color: Colors.red.shade200),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMenuCard({
    required IconData icon,
    required Color color,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: ListTile(
        leading: Container(
          padding: EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: color.withOpacity(0.1),
            shape: BoxShape.circle,
          ),
          child: Icon(icon, color: color),
        ),
        title: Text(title, style: TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text(subtitle, style: TextStyle(fontSize: 12, color: Colors.grey)),
        trailing: Icon(Icons.arrow_forward_ios, size: 16, color: Colors.grey),
        onTap: onTap,
      ),
    );
  }

  void _showLogoutDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Keluar'),
        content: Text('Apakah Anda yakin ingin keluar?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: Text('Batal')),
          ElevatedButton(
            onPressed: () async {
              Navigator.pop(context);
              await _apiService.logout();
              Navigator.pushNamedAndRemoveUntil(context, '/login', (route) => false);
            },
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            child: Text('Keluar'),
          ),
        ],
      ),
    );
  }
}