import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'api_service.dart';
import 'models.dart';

class EditKosPage extends StatefulWidget {
  final Kos kos;
  const EditKosPage({Key? key, required this.kos}) : super(key: key);

  @override
  _EditKosPageState createState() => _EditKosPageState();
}

class _EditKosPageState extends State<EditKosPage> {
  final _formKey = GlobalKey<FormState>();
  late TextEditingController _namaController;
  late TextEditingController _hargaController;
  late TextEditingController _alamatController;
  late TextEditingController _fasilitasController;
  String _jenisKos = 'putra';
  File? _imageFile;
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    _namaController = TextEditingController(text: widget.kos.name);
    _hargaController = TextEditingController(text: widget.kos.price.toInt().toString());
    _alamatController = TextEditingController(text: widget.kos.address);
    // Join array fasilitas jadi string koma
    _fasilitasController = TextEditingController(text: widget.kos.facilities.join(", "));
    _jenisKos = widget.kos.type.toLowerCase();
  }

  Future<void> _pickImage() async {
    final picked = await ImagePicker().pickImage(source: ImageSource.gallery);
    if (picked != null) {
      setState(() => _imageFile = File(picked.path));
    }
  }

  void _submit() async {
    if (_formKey.currentState!.validate()) {
      setState(() => _isLoading = true);
      
      bool success = await ApiService().updateKos(
        id: widget.kos.id,
        nama: _namaController.text,
        harga: _hargaController.text,
        alamat: _alamatController.text,
        fasilitas: _fasilitasController.text,
        jenis: _jenisKos,
        imagePath: _imageFile?.path, // Bisa null jika tidak ganti gambar
      );

      setState(() => _isLoading = false);

      if (success) {
        Navigator.pop(context);
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Berhasil diupdate!")));
      } else {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Gagal update")));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Edit Kos")),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              GestureDetector(
                onTap: _pickImage,
                child: Container(
                  height: 150,
                  width: double.infinity,
                  color: Colors.grey.shade200,
                  child: _imageFile != null
                      ? Image.file(_imageFile!, fit: BoxFit.cover)
                      : (widget.kos.images.isNotEmpty 
                          ? Image.network(widget.kos.images[0], fit: BoxFit.cover)
                          : Icon(Icons.camera_alt)),
                ),
              ),
              SizedBox(height: 8),
              Text("Ketuk gambar untuk mengganti"),
              SizedBox(height: 16),
              TextFormField(controller: _namaController, decoration: InputDecoration(labelText: "Nama Kos"), validator: (v) => v!.isEmpty ? "Isi nama" : null),
              TextFormField(controller: _hargaController, decoration: InputDecoration(labelText: "Harga"), keyboardType: TextInputType.number),
              TextFormField(controller: _alamatController, decoration: InputDecoration(labelText: "Alamat")),
              TextFormField(controller: _fasilitasController, decoration: InputDecoration(labelText: "Fasilitas")),
              DropdownButtonFormField<String>(
                value: _jenisKos,
                items: ['putra', 'putri', 'campur'].map((e) => DropdownMenuItem(value: e, child: Text(e.toUpperCase()))).toList(),
                onChanged: (v) => setState(() => _jenisKos = v!),
                decoration: InputDecoration(labelText: "Jenis Kos"),
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: _isLoading ? null : _submit,
                child: _isLoading ? CircularProgressIndicator() : Text("Simpan Perubahan"),
              ),
            ],
          ),
        ),
      ),
    );
  }
}