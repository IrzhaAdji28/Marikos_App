import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'api_service.dart';
import 'models.dart';

class ManageBookingPage extends StatefulWidget {
  @override
  _ManageBookingPageState createState() => _ManageBookingPageState();
}

class _ManageBookingPageState extends State<ManageBookingPage> {
  final ApiService _apiService = ApiService();
  late Future<List<Booking>> _incomingFuture;

  @override
  void initState() {
    super.initState();
    _incomingFuture = _apiService.getIncomingBookings();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Kelola Booking Masuk"),
        backgroundColor: Colors.purple.shade700,
        foregroundColor: Colors.white,
      ),
      body: FutureBuilder<List<Booking>>(
        future: _incomingFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) return Center(child: CircularProgressIndicator());
          if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return Center(child: Text("Belum ada yang menyewa kos Anda."));
          }

          return ListView.builder(
            padding: EdgeInsets.all(16),
            itemCount: snapshot.data!.length,
            itemBuilder: (context, index) {
              final booking = snapshot.data![index];
              return Card(
                margin: EdgeInsets.only(bottom: 12),
                child: ListTile(
                  leading: CircleAvatar(
                    backgroundColor: Colors.purple.shade100,
                    child: Icon(Icons.person, color: Colors.purple),
                  ),
                  title: Text(booking.kosName, style: TextStyle(fontWeight: FontWeight.bold)),
                  subtitle: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text("Penyewa: ${booking.userName}"), // Pastikan backend kirim 'user_name' / 'nama_penyewa'
                      Text(
                        "${DateFormat('d MMM').format(booking.checkInDate)} - ${DateFormat('d MMM').format(booking.checkOutDate)}",
                        style: TextStyle(fontSize: 12),
                      ),
                      Text(
                        "Rp ${NumberFormat('#,###').format(booking.totalPrice)}",
                        style: TextStyle(color: Colors.green, fontWeight: FontWeight.bold),
                      ),
                    ],
                  ),
                  trailing: Container(
                    padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: booking.status == 'lunas' || booking.status == 'disetujui' ? Colors.green : Colors.orange,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Text(
                      booking.status.toUpperCase(),
                      style: TextStyle(color: Colors.white, fontSize: 10),
                    ),
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}