import 'package:flutter/material.dart';
import 'models.dart';
import 'package:intl/intl.dart';
import 'api_service.dart';

class PaymentPage extends StatefulWidget {
  final Booking booking;

  const PaymentPage({Key? key, required this.booking}) : super(key: key);

  @override
  _PaymentPageState createState() => _PaymentPageState();
}

class _PaymentPageState extends State<PaymentPage> {
  bool _isQrGenerated = false;

  @override
  Widget build(BuildContext context) {
    // Generate data unik untuk QR
    String qrData = "MARIKOS-PAY-${widget.booking.id}-${widget.booking.totalPrice.toInt()}";
    String qrUrl = "https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=$qrData";

    return Scaffold(
      backgroundColor: Colors.grey.shade50, // Ubah warna background agar kartu putih lebih menonjol
      appBar: AppBar(
        title: Text("Pembayaran"),
        backgroundColor: Colors.purple.shade700,
        foregroundColor: Colors.white,
        centerTitle: true, // Judul di tengah
        elevation: 0,
      ),
      // PERBAIKAN 1: Gunakan Center agar konten vertikal di tengah
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center, // Pastikan column juga center
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              // Detail Harga
              Text("Total Tagihan", style: TextStyle(color: Colors.grey.shade600, fontSize: 16)),
              SizedBox(height: 8),
              Text(
                "Rp ${NumberFormat('#,###', 'id_ID').format(widget.booking.totalPrice)}",
                style: TextStyle(fontSize: 34, fontWeight: FontWeight.bold, color: Colors.purple.shade700),
              ),
              SizedBox(height: 40),

              // AREA KARTU QR CODE (Card Putih)
              Container(
                width: double.infinity, // Agar kartu melebar sesuai padding
                padding: EdgeInsets.symmetric(vertical: 40, horizontal: 20),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(24),
                  // Efek bayangan agar terlihat seperti "Card" melayang
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.08),
                      blurRadius: 20,
                      offset: Offset(0, 10),
                    )
                  ],
                ),
                child: Column(
                  children: [
                    Text(
                      _isQrGenerated ? "Scan QRIS untuk Bayar" : "Pilih Metode Pembayaran",
                      style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18, color: Colors.grey.shade800),
                    ),
                    SizedBox(height: 30),
                    
                    if (_isQrGenerated)
                      Image.network(
                        qrUrl,
                        width: 220,
                        height: 220,
                        loadingBuilder: (context, child, loadingProgress) {
                          if (loadingProgress == null) return child;
                          return Container(
                            width: 220, height: 220,
                            child: Center(child: CircularProgressIndicator()),
                          );
                        },
                        errorBuilder: (context, error, stackTrace) {
                          return Column(
                            children: [
                              Icon(Icons.broken_image, size: 50, color: Colors.grey),
                              Text("Gagal memuat QR", style: TextStyle(color: Colors.grey)),
                            ],
                          );
                        },
                      )
                    else
                      Icon(Icons.qr_code_scanner, size: 120, color: Colors.grey.shade200),
                      
                    SizedBox(height: 30),
                    
                    if (!_isQrGenerated)
                      SizedBox(
                        width: double.infinity,
                        height: 50,
                        child: ElevatedButton.icon(
                          onPressed: () {
                            setState(() {
                              _isQrGenerated = true;
                            });
                          },
                          icon: Icon(Icons.qr_code),
                          label: Text("Generate QRIS"),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.purple.shade700,
                            foregroundColor: Colors.white,
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                            elevation: 0,
                          ),
                        ),
                      ),
                  ],
                ),
              ),

              SizedBox(height: 40),
              
              // TOMBOL KONFIRMASI (Hanya muncul jika QR sudah digenerate)
              if (_isQrGenerated)
                SizedBox(
                  width: double.infinity,
                  height: 55,
                  child: ElevatedButton(
                    onPressed: () async {
                      // Loading
                      showDialog(
                        context: context,
                        barrierDismissible: false,
                        builder: (c) => Center(child: CircularProgressIndicator()),
                      );

                      // Panggil API Update Status
                      bool success = await ApiService().updateBookingStatus(widget.booking.id);
                      
                      Navigator.pop(context); // Tutup Loading

                      if (success) {
                        await showDialog(
                          context: context,
                          builder: (c) => AlertDialog(
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                            contentPadding: EdgeInsets.all(24),
                            content: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Container(
                                  padding: EdgeInsets.all(16),
                                  decoration: BoxDecoration(color: Colors.green.shade50, shape: BoxShape.circle),
                                  child: Icon(Icons.check, color: Colors.green, size: 40),
                                ),
                                SizedBox(height: 16),
                                Text("Pembayaran Berhasil!", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
                                SizedBox(height: 8),
                                Text("Terima kasih, pesanan Anda telah lunas.", textAlign: TextAlign.center, style: TextStyle(color: Colors.grey)),
                                SizedBox(height: 24),
                                SizedBox(
                                  width: double.infinity,
                                  child: ElevatedButton(
                                    onPressed: () {
                                      Navigator.pop(c);
                                      Navigator.pop(context); // Kembali ke Home
                                    },
                                    style: ElevatedButton.styleFrom(backgroundColor: Colors.green, foregroundColor: Colors.white),
                                    child: Text("OK"),
                                  ),
                                )
                              ],
                            ),
                          ),
                        );
                      } else {
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(content: Text("Gagal verifikasi pembayaran"), backgroundColor: Colors.red)
                        );
                      }
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.green, 
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      elevation: 2,
                    ),
                    child: Text("Saya Sudah Scan & Bayar", style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}