import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'chat_list_page.dart';
import 'models.dart';
import 'profile_page.dart';
import 'api_service.dart';
import 'payment_page.dart';

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int _currentIndex = 0;
  
  // Service API
  final ApiService _apiService = ApiService();
  
  // Future variables untuk data
  late Future<List<Kos>> _futureKos;
  late Future<List<Booking>> _futureBookings;

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  void _loadData() {
    _futureKos = _apiService.getKos();
    _futureBookings = _apiService.getUserBookings();
  }

  // Fungsi untuk refresh saat pindah tab agar data selalu update
  void _onTabTapped(int index) {
    setState(() {
      _currentIndex = index;
      if (index == 0) _futureKos = _apiService.getKos();
      if (index == 1) _futureBookings = _apiService.getUserBookings();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('MariKos'),
        backgroundColor: Colors.purple.shade700,
        foregroundColor: Colors.white,
        automaticallyImplyLeading: false, // Hilangkan tombol back di home
      ),
      body: _buildCurrentPage(),
      bottomNavigationBar: _buildBottomNavigationBar(),
    );
  }

  Widget _buildCurrentPage() {
    switch (_currentIndex) {
      case 0:
        return _buildHomeContent();
      case 1:
        return _buildBookingsPage();
      case 2:
        return ChatListPage(); // Halaman Chat
      case 3:
        return ProfilePage(); // Halaman Profil
      default:
        return _buildHomeContent();
    }
  }

  // ===========================================================================
  // TAB 1: BERANDA (HOME)
  // ===========================================================================
  
  Widget _buildHomeContent() {
    return RefreshIndicator(
      onRefresh: () async {
        setState(() {
          _futureKos = _apiService.getKos();
        });
      },
      child: SingleChildScrollView(
        padding: EdgeInsets.all(16),
        physics: AlwaysScrollableScrollPhysics(),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildWelcomeHeader(),
            SizedBox(height: 24),
            _buildQuickSearch(),
            SizedBox(height: 24),
            _buildRecentKosHeader(),
            SizedBox(height: 12),
            _buildKosList(),
          ],
        ),
      ),
    );
  }

  Widget _buildWelcomeHeader() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Selamat Datang!',
          style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.grey.shade800),
        ),
        SizedBox(height: 4),
        Text(
          'Temukan kos impian Anda dengan mudah',
          style: TextStyle(fontSize: 16, color: Colors.grey.shade600),
        ),
      ],
    );
  }

  Widget _buildQuickSearch() {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Cari Kos', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: TextField(
                    readOnly: true,
                    onTap: () => Navigator.pushNamed(context, '/search'),
                    decoration: InputDecoration(
                      hintText: 'Lokasi atau nama kos...',
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                      contentPadding: EdgeInsets.symmetric(horizontal: 16),
                      filled: true,
                      fillColor: Colors.grey.shade50,
                    ),
                  ),
                ),
                SizedBox(width: 12),
                Container(
                  decoration: BoxDecoration(
                    color: Colors.purple.shade700,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: IconButton(
                    icon: Icon(Icons.search, color: Colors.white),
                    onPressed: () => Navigator.pushNamed(context, '/search'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildRecentKosHeader() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text('Kos Terbaru', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        TextButton(
          onPressed: () => Navigator.pushNamed(context, '/search'),
          child: Text('Lihat Semua', style: TextStyle(color: Colors.purple.shade700)),
        ),
      ],
    );
  }

  Widget _buildKosList() {
    return FutureBuilder<List<Kos>>(
      future: _futureKos,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return Center(child: Padding(padding: EdgeInsets.all(32), child: CircularProgressIndicator()));
        } else if (snapshot.hasError) {
          return Center(child: Text("Gagal memuat data. Periksa koneksi internet."));
        } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
          return Center(child: Text("Belum ada data kos tersedia"));
        }

        return Column(
          children: snapshot.data!.map((kos) => _buildKosCard(kos)).toList(),
        );
      },
    );
  }

  Widget _buildKosCard(Kos kos) {
    return Card(
      margin: EdgeInsets.only(bottom: 16),
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: () async {
          // Navigasi ke Detail Kos
          await Navigator.pushNamed(context, '/kos-detail', arguments: kos);
          // Refresh booking jika user melakukan booking dan kembali
          setState(() {
            _futureBookings = _apiService.getUserBookings();
          });
        },
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Bagian Gambar
            Container(
              height: 160,
              width: double.infinity,
              child: Stack(
                fit: StackFit.expand,
                children: [
                  kos.images.isNotEmpty
                      ? Image.network(kos.images[0], fit: BoxFit.cover,
                          errorBuilder: (c, e, s) => Container(color: Colors.grey.shade300, child: Icon(Icons.broken_image)))
                      : Container(color: Colors.grey.shade300, child: Icon(Icons.home_work, size: 50)),
                  Positioned(
                    top: 8, left: 8,
                    child: Container(
                      padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                        color: _getTypeColor(kos.type).withOpacity(0.9),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Text(
                        kos.type.toUpperCase(),
                        style: TextStyle(fontSize: 10, color: Colors.white, fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            // Bagian Informasi
            Padding(
              padding: EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Expanded(
                        child: Text(
                          kos.name,
                          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      Row(
                        children: [
                          Icon(Icons.star, color: Colors.amber, size: 16),
                          SizedBox(width: 4),
                          Text(kos.rating.toString()),
                        ],
                      ),
                    ],
                  ),
                  SizedBox(height: 4),
                  Row(
                    children: [
                      Icon(Icons.location_on, size: 14, color: Colors.grey.shade700),
                      SizedBox(width: 4),
                      Expanded(
                        child: Text(kos.location, style: TextStyle(color: Colors.grey.shade700), overflow: TextOverflow.ellipsis),
                      ),
                    ],
                  ),
                  SizedBox(height: 8),
                  Text(
                    'Rp ${NumberFormat.decimalPattern('id').format(kos.price)} / bulan',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.purple.shade700),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ===========================================================================
  // TAB 2: PEMESANAN (BOOKINGS)
  // ===========================================================================

  Widget _buildBookingsPage() {
    return FutureBuilder<List<Booking>>(
      future: _futureBookings,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return Center(child: CircularProgressIndicator());
        }
        if (!snapshot.hasData || snapshot.data!.isEmpty) {
          return Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.assignment_outlined, size: 80, color: Colors.grey.shade300),
                SizedBox(height: 16),
                Text("Belum ada booking aktif"),
                Text("Pesan kos sekarang!", style: TextStyle(color: Colors.grey)),
              ],
            ),
          );
        }

        return RefreshIndicator(
          onRefresh: () async {
            setState(() {
              _futureBookings = _apiService.getUserBookings();
            });
          },
          child: ListView.builder(
            padding: EdgeInsets.all(16),
            itemCount: snapshot.data!.length,
            itemBuilder: (context, index) {
              return _buildBookingCard(snapshot.data![index]);
            },
          ),
        );
      },
    );
  }

  // KARTU BOOKING (DESAIN SESUAI REQUEST)
  Widget _buildBookingCard(Booking booking) {
    bool isPending = booking.status == 'pending';

    return GestureDetector(
      onTap: () {
        // Jika status pending, buka halaman pembayaran
        if (isPending) {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => PaymentPage(booking: booking)),
          ).then((_) {
            // Refresh data setelah kembali dari halaman payment
            setState(() {
              _futureBookings = _apiService.getUserBookings();
            });
          });
        }
      },
      child: Container(
        margin: EdgeInsets.only(bottom: 16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          // Shadow halus
          boxShadow: [
            BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 10, offset: Offset(0, 4))
          ],
          border: Border.all(color: Colors.grey.shade200),
        ),
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // HEADER: Nama Kos & Status Pill
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: Text(
                      booking.kosName,
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                      maxLines: 2, overflow: TextOverflow.ellipsis,
                    ),
                  ),
                  SizedBox(width: 8),
                  Container(
                    padding: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      color: isPending ? Colors.orange : Colors.green,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Text(
                      isPending ? "MENUNGGU PEMBAYARAN" : "LUNAS",
                      style: TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold),
                    ),
                  ),
                ],
              ),
              SizedBox(height: 12),
              
              // INFO: Detail Pemesan
              Text("Pemesan: ${booking.userName}", style: TextStyle(color: Colors.grey[600], fontSize: 13)),
              SizedBox(height: 4),
              Text(
                "Tanggal: ${DateFormat('d MMM yyyy', 'id_ID').format(booking.checkInDate)} - ${DateFormat('d MMM yyyy', 'id_ID').format(booking.checkOutDate)}",
                style: TextStyle(color: Colors.grey[600], fontSize: 13),
              ),
              
              SizedBox(height: 16),
              Divider(color: Colors.grey.shade200),
              SizedBox(height: 8),

              // FOOTER: Total Harga
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text("Total Harga", style: TextStyle(color: Colors.grey[700])),
                  Text(
                    "Rp ${NumberFormat('#,###', 'id_ID').format(booking.totalPrice)}",
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.purple.shade700),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ===========================================================================
  // UTILS & NAVIGATION
  // ===========================================================================

  Color _getTypeColor(String type) {
    switch (type.toLowerCase()) {
      case 'putra': return Colors.blue.shade700;
      case 'putri': return Colors.pink.shade400;
      case 'campur': return Colors.purple.shade700;
      default: return Colors.grey;
    }
  }

  BottomNavigationBar _buildBottomNavigationBar() {
    return BottomNavigationBar(
      currentIndex: _currentIndex,
      onTap: _onTabTapped, // Panggil fungsi yang ada setState dan refresh data
      type: BottomNavigationBarType.fixed,
      selectedItemColor: Colors.purple.shade700,
      unselectedItemColor: Colors.grey.shade600,
      items: [
        BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Beranda'),
        BottomNavigationBarItem(icon: Icon(Icons.assignment), label: 'Pemesanan'),
        BottomNavigationBarItem(icon: Icon(Icons.chat), label: 'Chat'),
        BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Profil'),
      ],
    );
  }
}