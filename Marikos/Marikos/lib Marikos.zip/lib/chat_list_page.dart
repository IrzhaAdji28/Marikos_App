import 'package:flutter/material.dart';
import 'chat_page.dart';
import 'api_service.dart';

class ChatListPage extends StatefulWidget {
  const ChatListPage({super.key});

  @override
  State<ChatListPage> createState() => _ChatListPageState();
}

class _ChatListPageState extends State<ChatListPage> {
  final ApiService _apiService = ApiService();
  
  // Variabel untuk menampung data
  Future<List<Map<String, dynamic>>>? _chatRoomsFuture;
  String? _currentUserId;

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  // Fungsi untuk mengambil ID User dulu, baru ambil data chat
  void _loadData() async {
    final userId = await _apiService.getCurrentUserId();
    
    if (mounted) {
      setState(() {
        _currentUserId = userId;
        // Hanya panggil API jika userId ditemukan
        if (userId != null) {
          _chatRoomsFuture = _apiService.getChatRooms(userId);
        }
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Chat Pemilik Kos"),
        backgroundColor: Colors.purple.shade700,
        foregroundColor: Colors.white,
      ),
      // Cek apakah user ID sudah ada
      body: _currentUserId == null
          ? const Center(child: CircularProgressIndicator()) // Loading saat ambil ID
          : FutureBuilder<List<Map<String, dynamic>>>(
              future: _chatRoomsFuture,
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                } else if (snapshot.hasError) {
                  return Center(child: Text("Gagal memuat chat: ${snapshot.error}"));
                } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
                  return const Center(child: Text("Belum ada percakapan"));
                }

                return ListView.builder(
                  itemCount: snapshot.data!.length,
                  itemBuilder: (context, index) {
                    final chat = snapshot.data![index];
                    final partnerName = chat['partner_name'] ?? 'User';
                    final partnerId = chat['partner_id'].toString();
                    final lastMsg = chat['last_message'] ?? '';
                    
                    final initial = partnerName.isNotEmpty ? partnerName[0].toUpperCase() : '?';

                    return ListTile(
                      leading: CircleAvatar(
                        backgroundColor: Colors.purple.shade100,
                        child: Text(initial, style: TextStyle(color: Colors.purple.shade700)),
                      ),
                      title: Text(
                        partnerName,
                        style: const TextStyle(fontWeight: FontWeight.bold),
                      ),
                      subtitle: Text(
                        lastMsg,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(color: Colors.grey.shade700),
                      ),
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => ChatPage(
                              receiverId: partnerId,
                              receiverName: partnerName,
                            ),
                          ),
                        ).then((_) {
                          // Refresh halaman saat kembali
                          if (_currentUserId != null) {
                            setState(() {
                              _chatRoomsFuture = _apiService.getChatRooms(_currentUserId!);
                            });
                          }
                        });
                      },
                    );
                  },
                );
              },
            ),
    );
  }
}