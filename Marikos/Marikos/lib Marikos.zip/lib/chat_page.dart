import 'package:flutter/material.dart';
import 'models.dart';
import 'api_service.dart';

class ChatPage extends StatefulWidget {
  final String receiverId;
  final String receiverName;

  const ChatPage({
    Key? key,
    required this.receiverId,
    required this.receiverName,
  }) : super(key: key);

  @override
  _ChatPageState createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> {
  final _messageController = TextEditingController();
  final ApiService _apiService = ApiService();
  
  String? _currentUserId; // Dibuat nullable
  List<Message> _messages = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _initializePage();
  }

  // 1. Ambil ID User
  void _initializePage() async {
    final userId = await _apiService.getCurrentUserId();
    if (mounted) {
      setState(() {
        _currentUserId = userId;
      });
      
      if (userId != null) {
        _loadMessages();
      } else {
        setState(() => _isLoading = false);
      }
    }
  }

  // 2. Load Pesan
  void _loadMessages() async {
    // Pastikan ID tidak null
    if (_currentUserId == null) return;

    // Gunakan tanda ! karena kita sudah yakin tidak null
    final msgs = await _apiService.getMessages(_currentUserId!, widget.receiverId);
    
    if (mounted) {
      setState(() {
        _messages = msgs;
        _isLoading = false;
      });
    }
  }

  // 3. Kirim Pesan
  void _sendMessage() async {
    // Cek validasi input dan ID user
    if (_messageController.text.trim().isEmpty || _currentUserId == null) return;

    final content = _messageController.text.trim();
    _messageController.clear();

    // Tampilkan di UI secara lokal (Optimistic UI)
    final tempMsg = Message(
      id: 'temp',
      senderId: _currentUserId!,
      receiverId: widget.receiverId,
      content: content,
      timestamp: DateTime.now(),
      isRead: false, 
    );

    setState(() {
      _messages.add(tempMsg);
    });

    // Kirim ke Server
    bool success = await _apiService.sendMessage(
      _currentUserId!, 
      widget.receiverId, 
      content
    );

    if (success) {
      // Reload agar sinkron
      _loadMessages();
    } else {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Gagal mengirim pesan")),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            CircleAvatar(
              radius: 18,
              backgroundColor: Colors.purple.shade100,
              child: Icon(Icons.person, size: 20, color: Colors.purple.shade700),
            ),
            SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(widget.receiverName, style: TextStyle(fontSize: 16)),
                  Text('Online', style: TextStyle(fontSize: 12, color: Colors.green)),
                ],
              ),
            ),
          ],
        ),
      ),
      body: Column(
        children: [
          Expanded(
            child: _isLoading
                ? Center(child: CircularProgressIndicator())
                : _messages.isEmpty
                    ? Center(child: Text("Mulai percakapan dengan ${widget.receiverName}"))
                    : ListView.builder(
                        padding: EdgeInsets.all(16),
                        itemCount: _messages.length,
                        itemBuilder: (context, index) {
                          final message = _messages[index];
                          final isMe = message.senderId == _currentUserId;
                          return _buildMessageBubble(message, isMe);
                        },
                      ),
          ),
          _buildMessageInput(),
        ],
      ),
    );
  }

  Widget _buildMessageBubble(Message message, bool isMe) {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: isMe ? MainAxisAlignment.end : MainAxisAlignment.start,
        children: [
          if (!isMe) ...[
            CircleAvatar(
              radius: 16,
              backgroundColor: Colors.grey.shade300,
              child: Icon(Icons.person, size: 16, color: Colors.grey.shade600),
            ),
            SizedBox(width: 8),
          ],
          Flexible(
            child: Container(
              padding: EdgeInsets.symmetric(horizontal: 16, vertical: 10),
              decoration: BoxDecoration(
                color: isMe ? Colors.purple.shade700 : Colors.grey.shade200,
                borderRadius: BorderRadius.circular(16).copyWith(
                  bottomRight: isMe ? Radius.zero : null,
                  bottomLeft: !isMe ? Radius.zero : null,
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    message.content,
                    style: TextStyle(color: isMe ? Colors.white : Colors.black87),
                  ),
                  SizedBox(height: 4),
                  Text(
                    "${message.timestamp.hour}:${message.timestamp.minute.toString().padLeft(2,'0')}",
                    style: TextStyle(
                      fontSize: 10,
                      color: isMe ? Colors.white70 : Colors.grey.shade600,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMessageInput() {
    return Container(
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        boxShadow: [BoxShadow(blurRadius: 4, color: Colors.black12)],
      ),
      child: Row(
        children: [
          Expanded(
            child: TextField(
              controller: _messageController,
              decoration: InputDecoration(
                hintText: 'Ketik pesan...',
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(24)),
                contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              ),
              onSubmitted: (_) => _sendMessage(),
            ),
          ),
          SizedBox(width: 8),
          CircleAvatar(
            backgroundColor: Colors.purple.shade700,
            child: IconButton(
              icon: Icon(Icons.send, color: Colors.white),
              onPressed: _sendMessage,
            ),
          ),
        ],
      ),
    );
  }
}